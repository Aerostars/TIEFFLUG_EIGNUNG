Modul einrichten ---->TIEFLUG_EIGNUNG

DISTRIBUTION erstellen f�r Modul TIEFFLUG_EIGNUNG

=========================================

C:\Users\Mein>cd.. && cd..
DEVELOPMENT VERSION VON DISTRIBUTION
======================================
C:\>cd MAKE_DISTRIBUTION

C:\MAKE_DISTRIBUTION>py -3.6 setup.pyw develop  
======================================
CHECKING MODUL!!!
====================
C:\MAKE_DISTRIBUTION>py -3.6
Python 3.6.2 (v3.6.2:5fd33b5, Jul  8 2017, 04:14:34) [MSC v.1900 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>> import TIEFFLUG_EIGNUNG
>>> help(TIEFFLUG_EIGNUNG)
>>>exit()